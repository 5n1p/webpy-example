"""passlib - suite of password hashing & generation routinges"""

__version__ = '1.6.1'
