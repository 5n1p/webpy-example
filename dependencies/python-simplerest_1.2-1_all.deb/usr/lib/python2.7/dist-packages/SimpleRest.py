#!/usr/bin/python

import os
import json
import time
import urllib
import urllib2
import MultipartPostHandler
import cookielib

COOKIE_FILE = '.cookies'

def encoded_dict(in_dict):
  out_dict = {}
  for k, v in in_dict.iteritems():
    if isinstance(v, unicode):
      v = v.encode('utf8')
    elif isinstance(v, str):
      # Must be encoded in UTF-8
      v.decode('utf8')
    out_dict[k] = v
  return out_dict

class Rest:
  """
  This class provides the following features:
    o GET, POST, PUT, DELETE and HEAD HTTP methods
    o POST using either application/x-www-form-urlencoded or
      multipart/formdata encodings
    o returns JSON object with the results if appropriate
  """

  HEADERS = {
    'User-Agent'    : 'SimpleRest (Python-urllib/2.6)',
    'Accept'        : 'application/json'
  }

  def __init__(self, url, parameters={}, cookie_file=False):
    """
    Instantiate a rest client for a given url and set of parameters.
    """
    self.url = url
    self.parameters = parameters
    self.response = None
    self.result = None

  def _generate_get_url(self):
    """
    Put the url together with parameters properly urlencoded
    """
    url = self.url
    if self.parameters:
      url = url + '?' + urllib.urlencode( self.parameters )
    return url

  def _get_response(self,req,multipart=False):
    """
    Send the request and return a response or error code
    """
    try:
      cj = cookielib.LWPCookieJar( COOKIE_FILE )
      if os.path.isfile( COOKIE_FILE ):
        cj.load( ignore_discard=True )
    except cookielib.LoadError, e:
      pass

    try:
      if multipart:
        opener = urllib2.build_opener( urllib2.HTTPCookieProcessor( cj ), MultipartPostHandler.MultipartPostHandler )
        self.response = opener.open( req, self.parameters )
      else:
        opener = urllib2.build_opener( urllib2.HTTPCookieProcessor( cj ) )
        urllib2.install_opener( opener )
        self.response = urllib2.urlopen( req )
    except urllib2.HTTPError, e:
      #print "%s"            % ( repr(e) ) 
      #print "code = %s"     % ( str(e.code) )
      #print "msg = %s"      % ( str(e.msg) )
      #print "hdrs = %s"     % ( str(e.hdrs) )
      #print "filename = %s" % ( str(e.filename) )
      #print "%s"            % ( str(e) )
      self.response = None
      self.result = "%s" % ( str(e) )

    try:
      cj.save( ignore_discard=True )
    except Exception, e:
      pass

 
  def _get_result(self):
    """
    Read the result from the response
    """
    if isinstance(self.response, urllib2.addinfourl) and not self.result:
      self.result = self.response.read()
    try:
      return json.loads( self.result )
    except:
      return self.result

  def _save_result(self, destination):
    """
    Save the result to a file
    """
    if not isinstance(self.response, urllib2.addinfourl):
      return { 'status':'failure', 'message':'You suck' }
    # I don't know if I care about overwriting or not...
    #if os.path.exists( destination ):
    #  raise IOError( "%s: File exists" % destination )
    fh = open( destination, "wb" )
    try:
      while 1:
        buf = self.response.read( 8192 )
        if not buf:
          break
        fh.write( buf )
    except Exception, e:
      return { 'status' : 'error', 'message' : 'An error occurred: %s - %s' % ( str(e), repr(e) ) }
    finally:
      fh.close()
    return { 'status':'success', 'message':'You rock', 'filename':destination }

  def DOWNLOAD(self, destination):
    """
    This is a GET request with the parameters included in the
    url. The result is saved to a file rather than being returned.
    NOTE: All parameters in this request are encoded in the URL 
    """
    req = urllib2.Request( self._generate_get_url(), headers=self.HEADERS )
    self._get_response( req )
    return self._save_result( destination )

  def POSTDOWNLOAD(self, destination):
    """
    This is a POST request with the parameters included in the
    body. The result is saved to a file rather than being returned.
    NOTE: All parameters in this request are encoded in the URL 
    """
    req = urllib2.Request( self.url, self.parameters, headers=self.HEADERS )
    self._get_response( req, True )
    return self._save_result( destination )

  def GET(self):
    """
    This is a GET request with the parameters included in the
    url.
    NOTE: All parameters in this request are encoded in the URL 
    """
    req = urllib2.Request( self._generate_get_url(), headers=self.HEADERS )
    self._get_response( req )
    return self._get_result()

  def POST(self):
    """
    This is a POST request.
    NOTE: All parameters in this request are encoded as: application/x-www-form-urlencoded 
    """
    req = urllib2.Request( self.url,  urllib.urlencode( encoded_dict(self.parameters) ), headers=self.HEADERS )
    self._get_response( req )
    return self._get_result()

  def MULTIPOST(self):
    """
    This is a POST request.
    NOTE: All parameters in this request are encoded as: multipart/form-data
    """
    req = urllib2.Request( self.url, headers=self.HEADERS )
    self._get_response( req, True )
    return self._get_result()

  def PUT(self):
    """
    This is a PUT request.
    NOTE: All parameters in this request are encoded as: application/x-www-form-urlencoded
    NOTE: This is not a real put request.
    """
    req = urllib2.Request( self.url, self.parameters, headers=self.HEADERS )
    req.get_method = lambda: 'PUT'
    self._get_response( req )
    return self._get_result()

  def MULTIPUT(self):
    """
    This is a PUT request.
    NOTE: All parameters in this request are encoded as: multipart/form-data
    NOTE: This is not a real put request.
    """
    req = urllib2.Request( self.url, headers=self.HEADERS )
    req.get_method = lambda: 'PUT'
    self._get_response( req, True )
    return self._get_result()

  def DELETE(self):
    """
    This is a DELETE request with the parameters included in the
    url like a GET request.
    """
    req = urllib2.Request( self._generate_get_url(), headers=self.HEADERS )
    req.get_method = lambda: 'DELETE'
    self._get_response( req )
    return self._get_result()

  def HEAD(self):
    """
    This is a HEAD request with the parameters included in the
    url like a GET request.
    """
    req = urllib2.Request( self._generate_get_url(), headers=self.HEADERS )
    req.get_method = lambda: 'HEAD'
    self._get_response( req )
    # If we have a valid response, generate the JSON parsible result
    # from the HTTP headers so we can treat it the same as the other methods.
    if isinstance(self.response, urllib2.addinfourl):
      info = self.response.info()
      self.result = '{ "status" : "success", "size" : "%s", "type" : "%s", "date" : "%s" }' % (
        str( info.getheader('Content-Length','0') ),
        str( info.gettype() ),
        str( info.getheader('Last-Modified') )
      )
    else:
      self.result = '{ "status" : "failure" }'
    return self._get_result()

# End
