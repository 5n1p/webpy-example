Usage:
  Simplifies doing REST using OAuth (two-legged only) including
  support for both types of POST requests and uploading files

Example:
  import SimpleRest

  URL = 'http://localhost/face-server'

  def add_face( userid, upload_file ):
    parameters = {
      'userid' : userid,
      'file'   : open( upload_file, "rb" ),
    }
    rc = SimpleRest.Rest( URL, parameters)
    return rc.MULTIPOST()



